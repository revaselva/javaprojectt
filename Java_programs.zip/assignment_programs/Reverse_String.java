package assignment_programs;

public class Reverse_String 
{

	public static void main(String[] args) 
	{	       
		      String str= "Pradeep", rstr="";
		        char ch;
		       
		      System.out.print("Original word: ");
		      System.out.println("Pradeep");
		       
		      for (int i=0; i<str.length(); i++)
		      {
		        ch= str.charAt(i);
		        rstr= ch+rstr; 
		      }
		      System.out.println("Reversed word: "+ rstr);
		    }

	}
