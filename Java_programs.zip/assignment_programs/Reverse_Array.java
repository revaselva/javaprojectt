package assignment_programs;

public class Reverse_Array 
{

	public static void main(String[] args) 
	{
		int [] Array = {10,20,30,40,50};
		int i=0,j=Array.length-1;
		System.out.println("Before reversing:");
		for(int k=0;k<Array.length;k++)
		{
			System.out.println(Array[k]+"");
		}
		while(i<j)
		{
			int temp=Array[i];
			Array[i]=Array[j];
			Array[j]=temp;
			i=i+1;
			j=i-1;
		}
		System.out.println("After reversing:");
		for(int k=0;k<Array.length;k++)
		{
			System.out.println(Array[k]+"");
		}
	}

	}

