package assignment_programs;

public class Remove_first_last_letter 
{

	public static void main(String[] args) 
	{
		String word = "edubridge";

        if (word.length() >= 2) 
        {
            String result = word.substring(1, word.length() - 1);
            System.out.println("Modified word: " + result);
        } 
        else 
        {
            System.out.println("Word is too short to remove letters.");
        }

	}

}
