package assignment_programs;

import java.util.Scanner;

public class Palindrome 
{

	public static void main(String[] args) 
	{
	System.out.println("Enter the number:");
	Scanner s=new Scanner(System.in);
	int number=s.nextInt();
	int original=number;
	int check=0;
	int temp=0;
	while(number>0)
	{
		temp=number%10;
		check=(check*10)+temp;
		number=number/10;
		
	}
	if(original==check)
	{
		System.out.println("It is a Palindrome");
	
	}
	else
	{
		System.out.println("Not a Palindrome");
	}
	}

}
