package assignment_programs;

public class Del_numbers_array 
{

	public static void main(String[] args) 
	{
		double arr[]= {1,3,4,5,6,7.9,8,9.9,10};
		int len = arr.length;
		int temp[]= new int[arr.length];
		int j = 0;
		for(int i=0; i< len-1;i++)
		{
			if(arr[i] !=arr[i+1])
			{
				temp[j++]=(int) arr[i];
			}
		}
		temp[j++]=(int) arr[len - 1];
		for(int k=0;k<j;k++)
		{
			System.out.println(temp[k]);
		}
	}

}
