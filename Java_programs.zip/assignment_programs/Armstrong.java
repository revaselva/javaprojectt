package assignment_programs;

import java.util.Scanner;

public class Armstrong 
{

	public static void main(String[] args) 
	{
		int n;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Number:");
		n=s.nextInt();
		int temp= n;
		int r,sum=0;
		while(n>0)
		{
			r=n%10;
			n=n/10;
			sum = sum +r*r*r;
		}
		if(temp==sum)
		{
			System.out.println("Its an ArmsrtongNumber");
		}
		else
		{
			System.out.println("Not an Armstrong number");
		}
	}
	
	
}
