package assignment_programs;

public class Count_repeated_letters 
{

	public static void main(String[] args) 
	{
	String str="aapppttiiiie";
	

	}

}
